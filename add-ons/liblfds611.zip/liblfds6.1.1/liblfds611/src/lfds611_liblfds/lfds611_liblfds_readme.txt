This is not a data structure but rather functions internal to the library.

