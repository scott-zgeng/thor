/***** private prototypes *****/

